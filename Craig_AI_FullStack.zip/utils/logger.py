# Logger for Craig

def log_event(event):
    print(f"[CRAIG_LOG] {event}")

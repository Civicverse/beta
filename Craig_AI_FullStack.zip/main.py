# Entry point for Craig AI

if __name__ == '__main__':
    print('Craig is initializing...')

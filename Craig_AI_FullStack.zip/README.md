# Craig AI

Craig is the first CivicVerse-aligned, ethically governed open-source AI agent. It is uncensored, audit-ready, and owned by the people.

